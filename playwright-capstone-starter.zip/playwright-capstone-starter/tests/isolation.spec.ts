import { test, expect } from '../fixtures';

// Selenium: IsolationTests.seededAccountStartsClean
//   Creates an account through the API, logs in as it through the login page, and checks:
//   the welcome text, 3 holdings and the balance "₹1,25,000.50".
test('12 A freshly seeded account starts with the default holdings and balance', async ({

  loggedInPage,  
}) =>{
  const {page,account} = loggedInPage;

  await expect(
    page.getByRole('heading', {level: 1})
  ).toHaveText(`Welcome, ${account.username}`);

  await expect(
    page.getByText('Bluechip Growth Fund')
  ).toBeVisible();

    await expect(
      page.getByText('National Infra Bond')
    ).toBeVisible();

    await expect(
      page.getByText('Globbal Equity Index')
    ).toBeVisible();

    await expect(
      page.getByRole('button', {name:/Sell V Redeem/i})
    ).toHaveCount(3);

    await expect(
      page.getByText('1,25,000.50')
    ).toBeVisible();

  });
