import { test, expect } from '../fixtures';

// All five tests open the sell form for the first holding, "Bluechip Growth Fund".
// The sell form has two groups of radio buttons (Market and Settlement type), a quantity,
// a confirmation checkbox and a "Submit for Redemption" button.

// Selenium: SellTests.sellCashOnNse
//   Choose market NSE, settlement Cash, quantity 1, confirm, submit.
//   Expect the confirmation heading "Transaction submitted and under process",
//   the status "processing" and the settlement "cash".
test('07 Selling on NSE with cash settlement is confirmed', async ({loggedInPage,  
}) => {
  const{page} = loggedInPage;
  
  await page.getByText('Sell/Redeem').first().click();

  await page.getByLabel('NSE').check();

  await page.getByLabel('Cash').check();

  await page.getByLabel('Quantity to sell').fill('1');

  await page.getByLabel('I confirm the above details are correct').check();

  await page.getByRole('button', {
    name:/Submit for Redemption/i,
  }).click();

  await expect page.getByText(/Transation submitted/i)
  .toBeVisible();
});

// Selenium: SellTests.chequeNeedsBranch
//   Choose Cheque, quantity 1, confirm, submit, without filling in a branch.
//   Expect the alert "Cheque settlement requires a branch" and to stay on the sell page.
test('08 Cheque settlement without a branch is rejected', async ({
  loggedInPage,
}) => {
  const {page} = loggedInPage;

  await page.getByText('Sell/Redeem').first().click();

  await page.getByLabel('Cheque').check();

  await page.getByLabel('Quantity to sell').fill('1');

  await page.getByLabel('I confirm the above details are correct').check();

  await page.getByRole('button', {
    name:/Submit for Redemption/i,
  }).click();

  await expect(page.getByText(
    'Cheque settlement requires a branch'
  )).toBeVisible();

});

// Selenium: SellTests.chequeWithBranchConfirms
//   Choose NSE and Cheque, branch "Fort, Mumbai", quantity 1, confirm, submit.
//   Expect the settlement "cheque" and the status "processing".
test('09 Cheque settlement with a branch is confirmed', async ({
  loggedInPage,
})=> {
  const{page} = loggedInPage;

  await page.getByText('Sell/Redeem').first().click();
  await page.getByLabel('NSE').check();
  await page.getByLabel('Cheque').check();
  await page.getByLabel(/branch/i).fill('Fort, Mumbai');
  await page.getByLabel('Quantity to sell').fill('1');

  await page.getByLabel('I confirm the above details are correct')
  .check();

  await page.getByRole('button', {
    name:/Submit for Redemption/i,

  }).click();

  await expect(
    page.getByText(/Transaction submitted/i)
  ).toBeVisible();
  
  await expect(
    page.getByText(/processing/i)
  ).toBeVisible();
});

// Selenium: SellTests.oversellIsRejected
//   Quantity 9999, confirm, submit. Expect an alert like "Only 120 units available to sell".
//   The number depends on the account, so match the shape of the sentence.
test('10 Selling more than is held is rejected', async ({
  loggedInPage,
}) => {
  const{page} = loggedInPage;

  await page.getByText('Sell/Redeem').first().click();

  await page.getByLabel('Quantity to sell').fill('9999');

  await page.
  getByLabel('I confirm the above details are correct')
  .check();

  await page.getByRole('button', {
    name:/Submit for Redemption/i,
  }).click();

  await expect(
    page.getByText(/Only.*units available to sell/i)
  ).toBeVisible();
});

// Selenium: SellTests.saleReducesQuantityOnServer
//   Ask the API for the holding's quantity, sell 2 through the UI, ask the API again,
//   expect the quantity to be 2 lower. Playwright's request fixture replaces the Java HttpClient.
test.fixme('11 A sale reduces the quantity held on the server', async ({
  loggedInPage,
}) => {

  const {page } = loggedInPage;

  await page.getByText('Sell/Redeem').first().click();

  const beforeQtyText = await page.
    getByText(/Available quantity:/i)
    .textContent();

  const beforeQty = Number(
    beforeQtyText?.match(/\d+/)?.[0]
  );

  await page.getByLabel('Quantity to sell').fill('2');
  await page.
    getByLabel('I confirm the above details are correct')
    .check();

    await page.getByRole('button', {
      name:/Submit for Redemption/i,
    }).click();

    await page.getByText('Back to dashboard').click();
    await page. getByText('Sell / Redeem').first().click();

    const afterQtyText = await page.
      getByText(/Available quantity:/i).
      textContent();

      const afterQty = Number(
        afterQtyText?.match(/\d+/)?.[0]

      );
      expect(afterQty).toBe(beforeQty - 2);

});
