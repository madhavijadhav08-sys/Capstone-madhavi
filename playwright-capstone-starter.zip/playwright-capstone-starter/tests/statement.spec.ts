import{test,expect} from '../fixtures';

// The dashboard has a "View statement" link that opens the statement in a NEW WINDOW.
// Selenium handled that with getWindowHandles() and switchTo().window().

// Selenium: StatementTests.statementOpensInNewWindow
//   Click the link, wait until there are two windows, switch to the new one, expect the
//   heading "Account Statement", close it, and return to the dashboard.
test('13 The statement opens in a new window', async ({
  loggedInPage,
}) => {

  const{page} = loggedInPage;
  const popupPromise = page.waitForEvent('popup');

  await page.getByText('View Statement').click();
  const statementPage = await popupPromise;

  await expect(
    statementPage.getByRole('heading',{
      name:/Account Statement/i,
 } )
  ).toBeVisible();

  await statementPage.close();
  await expect(page).toHaveURL(/dashboard/);

});


// Selenium: StatementTests.termsCanBeAcceptedInIframe
//   In the statement window there is an iframe titled "Statement terms" with an
//   "Accept terms" button. Click it and expect the text "Terms accepted" inside the frame.
//   Selenium used switchTo().frame() and switchTo().defaultContent().
test('14 The terms can be accepted inside the iframe', async (
  {
    loggedInPage,
  }
    ) => {
      
      const {page} = loggedInPage;
      const popupPromise = page.waitForEvent('popup');
      await page.getByText('View Statement').click();

      const statementPage = await popupPromise;

      const termsFrame = statementPage.frameLocator(
        'iframe[title="Statement terms"]'
      );

      await termsFrame
        .getByRole('button',{name:/Accept terms/i})
        .click();

      await expect(
        termsFrame.getByText(/Terms accpeted/i)

      ).toBeVisible();

      await statementPage.close();

});

// Selenium: StatementTests.marketFilterMultiSelect
//   The statement has a "Markets" multi-select. Choose BSE (1 holding, "National Infra Bond"),
//   then NSE and BSE together (3 holdings), then clear it (3 holdings again).
//   Selenium used the Select class: selectByValue, getAllSelectedOptions, deselectAll.
test('15 The market filter accepts several selections', async (
  {
    loggedInPage,
  }
) => {
  
    const {page} = loggedInPage;
    const popupPromise = page.waitForEvent('popup');
    await page.getByText('View Statement').click();

    const statementPage = await popupPromise;

    const markets = statementPage.locator('select');

    await markets.selectOption(['BSE']);

    await expect(
      statementPage.getByText('National Infra Bond')

    ).toBeVisible();

    await markets.selectOption([]);

    await expect(
      statementPage.locator('[data-testid="statement-row"]')
    ).toHaveCount(3);

    await statementPage.close();
});
